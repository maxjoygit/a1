<?php
// Read the incoming request
$data = json_decode(file_get_contents('php://input'), true);

// Check if the file name is provided
if (isset($data['file_name'])) {
    $fileName = $data['file_name'];
    $filePath = 'uploads/' . $fileName;

    // Check if the file exists
    if (file_exists($filePath)) {
        // Delete the file
        if (unlink($filePath)) {
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['success' => false, 'error' => 'Error deleting the file.']);
        }
    } else {
        echo json_encode(['success' => false, 'error' => 'File does not exist.']);
    }
} else {
    echo json_encode(['success' => false, 'error' => 'No file name provided.']);
}
?>
