<?php
// Define the upload directory and allowed file types
$uploadDir = 'uploads/';
$allowedTypes = ['image/jpeg', 'image/png', 'image/gif'];
$maxFileSize = 2 * 1024 * 1024; // Max file size: 2MB

// Check if the directory exists; if not, create it
if (!is_dir($uploadDir)) {
    mkdir($uploadDir, 0777, true);
}

// Check if a file is uploaded
if (isset($_FILES['file'])) {
    $file = $_FILES['file'];

    // Check for upload errors
    if ($file['error'] !== UPLOAD_ERR_OK) {
        http_response_code(400);
        echo json_encode(['error' => 'Upload error: ' . $file['error']]);
        exit;
    }

    // Check file type
    if (!in_array($file['type'], $allowedTypes)) {
        http_response_code(400);
        echo json_encode(['error' => 'Invalid file type. Only image files are allowed.']);
        exit;
    }

    // Check file size
    if ($file['size'] > $maxFileSize) {
        http_response_code(400);
        echo json_encode(['error' => 'File is too large. Max file size is 2MB.']);
        exit;
    }

    // Move the uploaded file to the upload directory
    $fileName = uniqid() . '_' . basename($file['name']);
    $filePath = $uploadDir . $fileName;

    if (move_uploaded_file($file['tmp_name'], $filePath)) {
        // Return a success response with the file URL
        echo json_encode([
            'message' => 'File uploaded successfully',
            'file_url' => $filePath,
            'file_name' => $fileName
        ]);
    } else {
        http_response_code(500);
        echo json_encode(['error' => 'File upload failed.']);
    }
} else {
    http_response_code(400);
    echo json_encode(['error' => 'No file uploaded.']);
}
?>
