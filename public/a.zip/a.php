<?php

const ENCRYPTION_KEY = 'N7dKq84tk4oQmMqopkhsnwavhgatewayenckey';

function encrypt($value)
{

    if (!$value) {
        return false;
    }
   
    $passphrase =   hash('sha256', ENCRYPTION_KEY);

    $key = openssl_encrypt($value, "AES-256-CBC",  $passphrase, 0, substr($passphrase, 0, 16));

    return base64_encode($key);
    
}
function decrypt($value)
{
    if (!$value) {
        return false;
    }
    $passphrase =   hash('sha256', ENCRYPTION_KEY);
    return openssl_decrypt(base64_decode($value), "AES-256-CBC",  $passphrase, 0, substr($passphrase, 0, 16));
}


var_dump(encrypt('1'));