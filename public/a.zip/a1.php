<?php

try {

    $domain = "google.com";

    $get = stream_context_create(
        [
            "ssl" => [
                "capture_peer_cert" => true
            ]
        ]
    );
    $read = stream_socket_client("ssl://" . $domain . ":443", $errno, $errstr, 30, STREAM_CLIENT_CONNECT, $get);

    $cert = stream_context_get_params($read);

    $peer_certificate = isset($cert['options']['ssl']) ? $cert['options']['ssl']['peer_certificate'] : null;

    $certinfo = openssl_x509_parse($peer_certificate);

    echo '<pre>';
    print_r($certinfo);
    echo '</pre>';
} catch (Exception $e) {

    echo $e->getMessage();
}
