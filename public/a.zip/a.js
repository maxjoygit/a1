const https = require('https');

const tls = require('tls');

async function getCertificateInfo(domain) {
  try {
    const certExpiryDate = await new Promise((resolve, reject) => {
      const options = {
        host: domain,
        port: 443,
        method: 'GET',
        rejectUnauthorized: true,
      };

      // Connect to the server using the TLS protocol to retrieve certificate details
    const socket = tls.connect(options, () => {
      const cert = socket.getPeerCertificate();
      if (cert) {
        // The 'valid_to' field contains the certificate expiry date
        resolve(cert.valid_to);
      } else {
        reject('No certificate found.');
      }
      socket.end(); // Close the connection after fetching the certificate
    });

    socket.on('error', (e) => {
      reject(`Error fetching certificate: ${e.message}`);
    });

      // Make an HTTPS request to the server
      const req = https.request(options, (res) => {
        // Fetch the certificate from the connection
        const cert = res.socket.getPeerCertificate();
        console.log(cert)
        if (cert) {
          resolve(cert.valid_to); // Resolve with the certificate expiry date
        } else {
          reject('No certificate found.');
        }
      });

      req.on('error', (e) => {
        reject(`Error fetching certificate: ${e.message}`);
      });

      req.end();
    });

    console.log('Certificate Expiry Date:', certExpiryDate);
  } catch (error) {
    console.error('Error:', error);
  }
}

// Usage example
//const domain = 'ashaspeechhearingclinic.com'; // Replace with the domain you want to check
const domain = 'logiccircle.co'; // Replace with the domain you want to check
getCertificateInfo(domain);
