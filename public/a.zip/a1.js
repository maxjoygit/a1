const moment = require('moment-timezone');

const dateStr = "Jun  5 07:36:09 2025 GMT";

const date = new Date(dateStr);

const timestamp = date.getTime()/1000;

const deadline = moment.unix(timestamp).format('YYYY-MM-DD HH:mm:ss');

const tzName = 'Asia/Kolkata';

const dt = moment.tz(tzName);

const dt1 = moment.tz(deadline, tzName);

const days = dt1.diff(dt, 'days');
const hours = dt1.diff(dt, 'hours') - (days * 24);
const minutes = dt1.diff(dt, 'minutes') - (days * 24 * 60) - (hours * 60);

const timeLeft = `${days} Days ${Math.ceil(hours)} Hours ${Math.ceil(minutes)} Minutes`;

console.log(timeLeft);
