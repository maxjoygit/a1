<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dropzone File Upload with PHP</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/dropzone@5.9.2/dist/min/dropzone.min.css">
    <style>
        /* Custom styling for the delete icon */
        .delete-btn {
            background-color: red;
            color: white;
            padding: 5px 10px;
            border: none;
            cursor: pointer;
            font-size: 14px;
            margin-top: 10px;
            border-radius: 5px;
        }

        .uploaded-file {
            margin: 10px 0;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            display: inline-block;
        }

        .uploaded-file img {
            width: 100px;
            height: 100px;
        }

        .uploaded-file p {
            margin: 5px 0;
        }
    </style>
</head>
<body>

    <h1>Upload Files with Dropzone.js</h1>

    <!-- File upload area (Dropzone) -->
    <form action="upload.php" class="dropzone" id="myDropzone"></form>

    <!-- Display the uploaded files with delete option -->
    <div id="uploaded-files">
        <h3>Uploaded Files:</h3>
        <!-- Uploaded files will appear here -->
    </div>

    <script src="https://cdn.jsdelivr.net/npm/dropzone@5.9.2/dist/min/dropzone.min.js"></script>
    <script>
        // Initialize Dropzone
        Dropzone.options.myDropzone = {
            paramName: "file", // The name of the file input for the server
            maxFilesize: 2, // Max file size (in MB)
            acceptedFiles: 'image/*', // Accept only image files
            dictDefaultMessage: "Drag & drop files here or click to upload",
            init: function() {
                this.on("error", function(file, errorMessage) {
                    // Handle error (display message)
                    alert("Error: " + errorMessage);
                    displayUploadedFile(file.name, errorMessage, false);
                });

                this.on("success", function(file, response) {
                    console.log("File uploaded successfully", response);
                    displayUploadedFile(response.file_name, 'Upload Successful', true, response.file_url);
                });
            }
        };

        // Function to display uploaded files and provide delete option
        function displayUploadedFile(fileName, statusMessage, success, fileUrl = '') {
            const uploadedFilesDiv = document.getElementById('uploaded-files');
            const fileDiv = document.createElement('div');
            fileDiv.classList.add('uploaded-file');
            fileDiv.innerHTML = `
                <img src="${fileUrl}" alt="${fileName}">
                <p>${fileName}</p>
                <p>${statusMessage}</p>
                <button class="delete-btn" onclick="deleteFile('${fileName}')">Delete</button>
            `;
            
            if (!success) {
                fileDiv.style.backgroundColor = "#ffdddd"; // Error color
            }

            uploadedFilesDiv.appendChild(fileDiv);
        }

        // Function to delete file
        function deleteFile(fileName) {
            if (confirm("Are you sure you want to delete this file?")) {
                fetch('delete.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({ file_name: fileName })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        alert('File deleted successfully!');
                        location.reload(); // Reload the page to update file list
                    } else {
                        alert('Error deleting file');
                    }
                })
                .catch(error => console.error('Error:', error));
            }
        }
    </script>
</body>
</html>
